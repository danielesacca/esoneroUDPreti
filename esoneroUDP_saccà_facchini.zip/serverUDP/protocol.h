/*
 * protocol.h
 *
 *  Created on: 9 dic 2021
 *      Author: danie
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_
#define ECHOMAX 255
#define PORT 48000

typedef struct{
	char symbol;
	int first;
	int second;
}msg;

typedef struct{
	int resultBeforeComma;
	int resultAfterComma;
	char error;
}answer;



#endif /* PROTOCOL_H_ */
