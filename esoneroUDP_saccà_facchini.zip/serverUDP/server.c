#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include "protocol.h"
#include <stdio.h>
#include <math.h>
#include <string.h> /* for memset() */

void ErrorHandler(char *errorMessage) {
	printf(errorMessage);
}

void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}

//Sum operation
int sum(int a, int b){
	return (a + b);
}

//Subtraction operation
int sub(int a, int b){
	return (a - b);
}

//Division operation
float division(float a, float b){
	if(b == 0){
		return NAN; //Not a number
	}
	return (a / b);
}

//Multiplication operation
int molt(int a, int b){
	return (a * b);
}

//Function that checks the symbol sent from a client
float operation(char symbol, int first, int second){
	float result = 0;
	if(symbol == '+'){
		result = (float)sum(first, second);
	}
	if(symbol == '-') {
		result = (float)sub(first,second);
	}
	if(symbol == 'x'){
		result = (float)molt(first, second);
	}
	if(symbol == '/') {
		result = division((float)first, (float)second);
	}
	return result;
}

//Procedure that splits a float number in 2 parts(the part before comma and after comma)
void controlPoint(float result, answer* resultStruct) {
	char buf[15] = "";
	char bufFirstNumber[10] = "";
	char bufSecondNumber[10] = "";
	int i = 0;
	int j = 0;

	sprintf(buf, "%.3f", result);
	for( i = 0; buf[i] != '.'; i++) {
		if(buf[i] != '.') bufFirstNumber[i] = buf[i];
	}
	while(buf[i] != '\0') {
		if(buf[i] != '.' && buf[i] != '\0') {
			bufSecondNumber[j] = buf[i];
			j++;
		}
		i++;
	}
	resultStruct->resultBeforeComma = atoi(bufFirstNumber);
	resultStruct->resultAfterComma = atoi(bufSecondNumber);
}

int main() {
#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2 ,2), &wsaData);
	if (iResult != 0) {
		printf ("error at WSASturtup\n");
		return EXIT_FAILURE;
	}
#endif
	int sock; //Socket
	msg message; //Struct to receive from client
	answer resultStruct; //Struct to send to client
	struct sockaddr_in echoServAddr;
	struct sockaddr_in echoClntAddr;
	struct hostent *remoteHost; //Struct for DNS implementation
	unsigned int cliAddrLen; //Client address struct size
	int recvMsgSize;
	float resultOperation; //Result of math operations

	// SOCKET CREATION
	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0){
		ErrorHandler("socket() failed");
	}
	// CREATION SERVER IP ADDRESS
	memset(&echoServAddr, 0, sizeof(echoServAddr));
	echoServAddr.sin_family = AF_INET;
	echoServAddr.sin_port = htons(PORT);
	echoServAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	// SOCKET BINDING
	if ((bind(sock, (struct sockaddr *)&echoServAddr, sizeof(echoServAddr))) < 0){
		ErrorHandler("bind() failed");
	}
	// RECEIVING ECHO STRING FROM CLIENT
	while(1) {
		resultStruct.error = *""; //Error string initialization
		cliAddrLen = sizeof(echoClntAddr);

		//Function to receive data from client
		recvMsgSize = recvfrom(sock, (void*)&message, sizeof(msg), 0, (struct sockaddr*)&echoClntAddr, (int*)&cliAddrLen);

		//Function to get a host name by an IP address
		remoteHost = gethostbyaddr((char *) &echoClntAddr.sin_addr.s_addr, 4, AF_INET);

		//Conversion for big-endian problem
		message.first = ntohl(message.first);
		message.second = ntohl(message.second);
		printf("request operation '%c %d %d' from client %s, ip: %s\n", message.symbol, message.first, message.second,
				remoteHost->h_name, inet_ntoa(echoClntAddr.sin_addr));

		//Calculating the results of the operation received
		resultOperation = operation(message.symbol, message.first, message.second);
		if(!isnan(resultOperation)) {
			if(message.symbol == '/') {

				//If the operation is a division, it splits the result into 2 different integers
				controlPoint(resultOperation, &resultStruct);
				resultStruct.resultBeforeComma = htonl(resultStruct.resultBeforeComma);
				resultStruct.resultAfterComma = htonl(resultStruct.resultAfterComma);
			}
			else {
				resultStruct.resultBeforeComma = (int)resultOperation;
				resultStruct.resultBeforeComma = htonl(resultStruct.resultBeforeComma);
			}
		}
		//Error division by 0
		else {
			resultStruct.error = 's';
		}
		// SENDING ECHO STRING TO CLIENT
		if (sendto(sock, (void *)&resultStruct, sizeof(answer), 0, (struct sockaddr *)&echoClntAddr, sizeof(echoClntAddr)) != recvMsgSize){
			ErrorHandler("sendto() sent different number of bytes than expected");
		}
	}
}
