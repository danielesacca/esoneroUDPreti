#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif
#include "protocol.h"
#include <stdio.h>
#include <string.h> /* for memset() */
#include <ctype.h>


void ErrorHandler(char *errorMessage) {
	printf(errorMessage);
}
void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}

//Procedure that checks if user input is empty
int controlEmptyInput(char *input) {
	int control = 0;
	for(int i = 0; i < strlen(input); i++) {
		if(input[i] != ' ') {
			control = 1;
		}
	}
	return control;
}

//It controls that user input is a number
int controlInput(char *input) {
	int control = 0;
	for(int i = 0; i < strlen(input); i++) {
		if(!isdigit(input[i])) {
			control = -1;
		}
		if(input[i-1] == '-' && i-1 == 0 && isdigit(input[i])){
			control = 0;
		}
	}
	return control;
}

//Function that checks if a number received is negative
int controlNegativeNumber(msg message) {
	int control = 0;
	if(message.first < 0 || message.second < 0) {
		control = -1;
	}
	if(message.first < 0 && message.second < 0) {
		control = 0;
	}
	return control;
}

// Function that splits a string in tokens
size_t controlToken(char input[], char symbolToken[], int numberOfToken, char *tokens[], size_t n) {
	for (char *p = strtok(input, symbolToken); p; p = strtok(NULL, symbolToken))
	{
		if (n >= numberOfToken)
		{
			// maximum number of storable tokens exceeded
			break;
		}
		tokens[n++] = p;
	}
	return n;
}

//Procedure to write the operation from the standard input and tokenizes it.
void inputOperation(msg *message, int socketClient){
	char inputFirst[10] = {0};
	char inputSecond[10] = {0};
	size_t n = 0;

	do {
		char input[50] = "";
		char *tokens[50] = {};
		memset(inputFirst, 0, 10);
		memset(inputSecond, 0, 10);
		printf("INSERT [sign] [operand1] [operand2]: ");
		gets(input);
		n = 0;
		if(controlEmptyInput(input) == 1) {
			n = controlToken(input, " ", 3, tokens, n);
			message->symbol = *tokens[0];
		}
		if(message->symbol != '=' && (n == 3)) {
			strcpy(inputFirst, tokens[1]);
			strcpy(inputSecond, tokens[2]);

			if(controlInput(inputFirst) == -1 || controlInput(inputSecond) == -1) {
				printf("Insert a valid input\n\n");
			}
		}
		if(n != 3 && message->symbol != '=') {
			printf("Insert a valid input\n\n");
		}

		if(message->symbol != '+' && message->symbol != '/' && message->symbol != 'x' && message->symbol != '-' && message->symbol != '=') {
			printf("Insert a valid sign\n\n");
		}

	}while((message->symbol != '+' && message->symbol != '/' && message->symbol != 'x' && message->symbol != '-' && message->symbol != '=')
			|| (controlInput(inputFirst) == -1 || controlInput(inputSecond) == -1) || ((n != 3) && (message->symbol != '=')));

	message->first = atoi(inputFirst);
	message->second = atoi(inputSecond);
	fflush(stdin);
}

int main(int argc, char *argv[]) {

#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2 ,2), &wsaData);
	if (iResult != 0) {
		printf ("error at WSASturtup\n");
		return EXIT_FAILURE;
	}
#endif

	char *tokens[50] = {}; //String to do tokenization
	msg message; //Message struct to send to server
	struct hostent *remoteHost; //Struct for DNS implementation
	int sock; //Socket
	answer resultOperation; //Struct to receive from server
	struct sockaddr_in echoServAddr;
	struct sockaddr_in fromAddr;
	unsigned int fromSize;
	int controlInputSign;
	char *address; //IP address for socket creation
	int port; //Port for socket creation

	// SOCKET CREATION
	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0){
		ErrorHandler("socket() failed\n");
		exit(EXIT_FAILURE);
	}
	//Connection to server through user parameters
	if (argc > 1) {
		controlToken(argv[1], ":", 2, tokens, 0);
		if(strcmp(tokens[0], " ") != 0 && strcmp(tokens[1], "48000") == 0 ) {
			remoteHost = gethostbyname(tokens[0]);
			address = inet_ntoa(*((struct in_addr*) remoteHost->h_addr_list[0]));
			port = atoi(tokens[1]); // if argument specified convert argument to binary
		}
		else {
			closesocket(sock);
			exit(EXIT_FAILURE);
		}
	}
	//Connection through default parameters
	else{
		remoteHost = gethostbyname("localhost");
		address = inet_ntoa(*((struct in_addr*) remoteHost->h_addr_list[0]));
		port = PORT; //Use default port number
	}
	if(port < 0){
		printf("bad port number %s \n", argv[2]);
	}
	memset(&echoServAddr, 0, sizeof(echoServAddr));
	echoServAddr.sin_family = PF_INET;
	echoServAddr.sin_addr.s_addr = inet_addr(address); //Server IP
	echoServAddr.sin_port = htons(port); //Server port

	while(1) {
		int numero1 = 0; //Number to print
		int numero2 = 0; //Number to print
		// SENDING ECHO STRING TO SERVER
		inputOperation(&message, sock);
		//Closing socket if input '='
		if(message.symbol == '=') {
			closesocket(sock);
			ClearWinSock();
			system("pause");
			return EXIT_SUCCESS;
		}
		controlInputSign = controlNegativeNumber(message);
		numero1 = message.first;
		numero2 = message.second;

		//Conversion for endianness
		message.first = htonl(message.first);
		message.second = htonl(message.second);

		if (sendto(sock, (void *)&message, sizeof(msg), 0, (struct sockaddr*)&echoServAddr, sizeof(echoServAddr)) != sizeof(msg)){
			ErrorHandler("sendto() sent different number of bytes than expected\n");
		}
		// RECEIVING ECHO STRING FROM SERVER
		fromSize = sizeof(fromAddr);
		recvfrom(sock, (void*)&resultOperation, sizeof(resultOperation), 0, (struct sockaddr*)&fromAddr, (int*)&fromSize);
		//It checks if the message received is sent from the same server
		if (echoServAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr)
		{
			fprintf(stderr, "Error: received a packet from unknown source.\n");
			exit(EXIT_FAILURE);
		}
		//If operation is a division, client receives two results that representing a float split in two integers
		if(message.symbol == '/') {
			//Control the message value received from the server
			if(resultOperation.error != 's') {
				resultOperation.resultBeforeComma = ntohl(resultOperation.resultBeforeComma);
				resultOperation.resultAfterComma = ntohl(resultOperation.resultAfterComma);

				//If operation is division, result before comma is 0 (example -0,15) and the operation is negative, insert the negative sign
				if(resultOperation.resultBeforeComma == 0 && controlInputSign == -1) {
					printf("Received result from server: %s, ip %s: %d %c %d = -%d,%03d\n\n", remoteHost->h_name, address, numero1,
							message.symbol, numero2, resultOperation.resultBeforeComma, resultOperation.resultAfterComma);
				}
				else {
					printf("Received result from server: %s, ip %s: %d %c %d = %d,%03d\n\n", remoteHost->h_name, address, numero1,
							message.symbol, numero2, resultOperation.resultBeforeComma, resultOperation.resultAfterComma);
				}
			}
			else {
				printf("Input error: impossible to divide by 0\n\n");
			}
		}
		else {
			resultOperation.resultBeforeComma = ntohl(resultOperation.resultBeforeComma);
			printf("Received result from server: %s, ip %s: %d %c %d = %d\n\n", remoteHost->h_name, address, numero1,
					message.symbol, numero2, resultOperation.resultBeforeComma);
		}
	}
}
